
// function onComplete(msg) {
//   var params = { complete: msg };
//   console.log(msg);  
//   $.post("/verification/iamreal", params)
//     .done(function( data ) {
//       console.log(data);
      
//       window.location.href("/verification");
//   });
// }


//   $.post("/verification/iamreal", params)
//     .done(function( data ) {
//       //console.log(data);
      
//       window.location.href = "/verification";
//   });
// }

;
